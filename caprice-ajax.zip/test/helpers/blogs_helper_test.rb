require 'test_helper'

class BlogsHelperTest < ActionView::TestCase
end
