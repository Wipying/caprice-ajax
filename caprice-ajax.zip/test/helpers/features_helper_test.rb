require 'test_helper'

class FeaturesHelperTest < ActionView::TestCase
end
