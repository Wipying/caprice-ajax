require 'test_helper'

class PortfoliosHelperTest < ActionView::TestCase
end
