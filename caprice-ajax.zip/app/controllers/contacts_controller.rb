class ContactsController < ApplicationController
  def index
  end
end
