class BlogsController < ApplicationController
  def blog
  end

  def blog2
  end

  def post
  end

  def post2
  end
end
