class HomesController < ApplicationController
  def index
  end
  
  def index2
  end
  def index3
  end
end
