class PortfoliosController < ApplicationController
  def index
  end

  def portfolio2
  end

  def portfolio3
  end

  def portfolio4
  end

  def post
  end
end
