class FeaturesController < ApplicationController
  def button
  end

  def tab
  end

  def testmonial
  end

  def typography
  end

  def icon
  end
end
